# **App Name**: Wardro

## Core Features:

- WearDraw AI Stylistic Assessment (Client Portal): An AI-powered tool that analyzes uploaded user outfits for stylistic coherence, provides a rating, and offers personalized suggestions for enhancement, simulating a professional stylist's critique.
- Personal Digital Wardrobe Management (Client Portal): Users can upload photos of their clothing items, add descriptive details, and organize their personal wardrobe digitally, enabling easy outfit planning and management.
- Curated Fashion Discovery & Visual Search (Client Portal): Clients can browse an exclusive catalog of curated fashion pieces and utilize an AI tool for visual search, allowing them to find similar items or style inspirations from images.
- Product & Inventory Catalog (Merchant Dashboard): Merchants can upload, edit, and categorize their product listings, including detailed descriptions, pricing, and high-quality images, to manage their online inventory.
- Operational Task Scheduling & Media Management (Merchant Dashboard): Merchants gain a tool for managing scheduled tasks, and the ability to upload and integrate rich media (video, audio, high-resolution images) directly into product displays.
- Data Visualization & Rapid Search (Merchant Dashboard): Provide merchants with an interface for comprehensive data visualization of inventory levels and key sales metrics, coupled with a rapid search function for efficient data retrieval.

## Style Guidelines:

- Dark Color Scheme for a luxurious, professional aesthetic.
- Primary Color: Metallic Gold (#D2AF69). Chosen to convey luxury and warmth, it's bold enough to stand out against a dark background while maintaining sophistication. HSL: 39, 44%, 62%.
- Background Color: Absolute Black (#080706). This deep, cinematic black creates a foundation of stark elegance and high contrast, setting the tone for 'Quiet Luxury'. HSL: 30, 16%, 3%.
- Accent Color: Deep Bronze (#6B472E). An analogous hue, approximately 25 degrees on the color wheel from the primary. This rich, dark brown with a metallic sheen complements the gold and black, providing depth and further accentuating luxury without being overpowering. HSL: 25, 40%, 30%.
- Headline Font: 'Playfair' (serif) for an elegant, high-end, and fashionable feel suitable for prominent titles. Body Font: 'PT Sans' (humanist sans-serif) for clean, professional readability across both client and merchant interfaces.
- Global Glassmorphism: All interactive containers will feature authentic layered glassmorphism (backdrop-filter: blur(15px)) combined with a subtle white-noise grain texture to convey depth and 'physical' material quality.
- Universal Motion Curve: All state changes (hover, click, focus, open, close) will utilize the cubic-bezier(0.16, 1, 0.3, 1) timing function, imparting a 'heavy,' intentional, and fluid motion characteristic of luxury.
- Micro-Interaction Details: Buttons will exhibit a soft 'glow pulse' on hover. Input fields will display a golden bottom-border that smoothly expands outward from the center when focused, simulating a focused light source.
- Client Portal Flow: Transitions for the client will be flowing and 'breathing,' with elements revealing themselves through soft, upward stagger animations to create an immersive experience.
- Merchant Dashboard Precision: The merchant interface will feature crisp, analytical transitions, with tables and data visualizations loading via rapid, sequential 'glass slide-ins' for efficient data consumption.
- Atmospheric Motion: Subtle, microscopic golden dust particles or light bokeh will react organically to user scroll speed, simulating an 'ambient' environment. Golden accents will act as dynamic light sources, with their reflections dancing across black surfaces during screen transitions.
- Material Fluidity & Cinematic Transitions: Glass elements will exhibit a slight 'liquid inertia' or a soft blur-trail when moved. Cinematic micro-transitions (like a soft lens flare or subtle spatial expansion) will fill any 'visual silence,' especially between processes like counter displays and result reveals.
'use server';
/**
 * @fileOverview An AI agent for stylistic outfit assessment.
 *
 * - aiOutfitAssessment - A function that handles the AI outfit assessment process.
 * - AiOutfitAssessmentInput - The input type for the aiOutfitAssessment function.
 * - AiOutfitAssessmentOutput - The return type for the aiOutfitAssessment function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiOutfitAssessmentInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of an outfit, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  description: z
    .string()
    .describe(
      'A detailed description of the outfit, including context like occasion or personal style preferences.'
    ),
});
export type AiOutfitAssessmentInput = z.infer<
  typeof AiOutfitAssessmentInputSchema
>;

const AiOutfitAssessmentOutputSchema = z.object({
  rating:
    z.number().min(1).max(10).describe('A stylistic rating for the outfit out of 10.'),
  assessment: z.string().describe('A detailed stylistic assessment of the outfit.'),
  suggestions: z
    .array(z.string())
    .describe('Personalized suggestions for enhancing the outfit.'),
});
export type AiOutfitAssessmentOutput = z.infer<
  typeof AiOutfitAssessmentOutputSchema
>;

export async function aiOutfitAssessment(
  input: AiOutfitAssessmentInput
): Promise<AiOutfitAssessmentOutput> {
  return aiOutfitAssessmentFlow(input);
}

const aiOutfitAssessmentPrompt = ai.definePrompt({
  name: 'aiOutfitAssessmentPrompt',
  input: {schema: AiOutfitAssessmentInputSchema},
  output: {schema: AiOutfitAssessmentOutputSchema},
  prompt: `You are an expert luxury fashion stylist named Wardro AI. Your task is to provide a comprehensive stylistic assessment of a user's outfit.

Analyze the provided image and description to:
1. Assign a stylistic rating to the outfit on a scale of 1 to 10.
2. Offer a detailed assessment of the outfit's strengths and weaknesses, considering factors like color harmony, silhouette, occasion appropriateness, and overall aesthetic.
3. Provide personalized, actionable suggestions for enhancing the outfit, focusing on accessories, layering, alternative pieces, or styling techniques.

Outfit Description: {{{description}}}
Outfit Photo: {{media url=photoDataUri}}`,
});

const aiOutfitAssessmentFlow = ai.defineFlow(
  {
    name: 'aiOutfitAssessmentFlow',
    inputSchema: AiOutfitAssessmentInputSchema,
    outputSchema: AiOutfitAssessmentOutputSchema,
  },
  async input => {
    const {output} = await aiOutfitAssessmentPrompt(input);
    return output!;
  }
);

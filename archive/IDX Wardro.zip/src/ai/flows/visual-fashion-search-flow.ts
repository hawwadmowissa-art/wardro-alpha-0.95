'use server';
/**
 * @fileOverview An AI-powered visual search tool for fashion items.
 *
 * - visualFashionSearch - A function that handles the visual fashion search process.
 * - VisualFashionSearchInput - The input type for the visualFashionSearch function.
 * - VisualFashionSearchOutput - The return type for the visualFashionSearch function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const VisualFashionSearchInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a fashion item or inspiration, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type VisualFashionSearchInput = z.infer<typeof VisualFashionSearchInputSchema>;

const FashionItemSchema = z.object({
  name: z.string().describe('The name of the fashion item.'),
  description: z.string().describe('A brief description of the fashion item.'),
  imageUrl: z.string().url().describe('A URL to an image of the fashion item.'),
  brand: z.string().optional().describe('The brand of the fashion item.'),
  price: z.number().optional().describe('The price of the fashion item, if available.'),
  similarityScore: z
    .number()
    .min(0)
    .max(1)
    .describe('A score indicating how similar this item is to the input image, from 0 (not similar) to 1 (very similar).'),
});

const VisualFashionSearchOutputSchema = z.object({
  similarItems: z.array(FashionItemSchema).describe('A list of fashion items similar to the input image.'),
  inspirationSummary: z.string().describe('A summary of style inspirations derived from the input image.'),
});
export type VisualFashionSearchOutput = z.infer<typeof VisualFashionSearchOutputSchema>;

export async function visualFashionSearch(input: VisualFashionSearchInput): Promise<VisualFashionSearchOutput> {
  return visualFashionSearchFlow(input);
}

const prompt = ai.definePrompt({
  name: 'visualFashionSearchPrompt',
  input: { schema: VisualFashionSearchInputSchema },
  output: { schema: VisualFashionSearchOutputSchema },
  prompt: `You are an AI-powered fashion stylist and catalog search assistant.

Your task is to analyze the provided image of a fashion item or style inspiration and identify similar items or derive style insights from a curated luxury fashion catalog.

Based on the image, provide:
1. A list of 3-5 similar fashion items. For each item, include its name, a brief description, a plausible image URL, an optional brand, an optional price, and a similarity score. Fabricate realistic URLs and details.
2. A concise summary of the overall style inspirations, trends, or aesthetic observed in the input image.

Photo: {{media url=photoDataUri}}

Focus on 'Quiet Luxury' and high-end fashion aesthetics in your suggestions.`,
});

const visualFashionSearchFlow = ai.defineFlow(
  {
    name: 'visualFashionSearchFlow',
    inputSchema: VisualFashionSearchInputSchema,
    outputSchema: VisualFashionSearchOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);

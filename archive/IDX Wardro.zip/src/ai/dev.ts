import { config } from 'dotenv';
config();

import '@/ai/flows/ai-outfit-assessment-flow.ts';
import '@/ai/flows/visual-fashion-search-flow.ts';
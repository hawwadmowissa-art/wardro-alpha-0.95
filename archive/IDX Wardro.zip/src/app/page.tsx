
"use client";

import { useState } from 'react';
import Link from 'next/link';
import { Card } from '@/components/ui/card';
import { User, Briefcase, Diamond } from 'lucide-react';
import { SplashScreen } from '@/components/layout/splash-screen';
import { Onboarding } from '@/components/layout/onboarding';

type ViewState = 'splash' | 'onboarding' | 'landing';

export default function Home() {
  const [view, setView] = useState<ViewState>('splash');

  return (
    <>
      {view === 'splash' && <SplashScreen onComplete={() => setView('onboarding')} />}
      {view === 'onboarding' && <Onboarding onComplete={() => setView('landing')} />}
      
      {view === 'landing' && (
        <main className="flex min-h-screen flex-col items-center justify-center p-6 bg-background/50">
          <div className="max-w-4xl w-full space-y-16 text-center">
            <header className="space-y-6 animate-reveal-up">
              <div className="flex justify-center mb-6">
                <Diamond className="w-16 h-16 text-primary" strokeWidth={1} />
              </div>
              <h1 className="text-8xl md:text-[10rem] font-brand text-primary tracking-[0.2em] leading-none uppercase">
                WARD<span className="lowercase">ro</span>
              </h1>
              <p className="text-muted-foreground text-xl md:text-2xl font-arabic font-light tracking-[0.1em] opacity-80">
                المنظومة السيادية للأزياء
              </p>
              <div className="pt-4">
                <span className="text-primary/40 text-[10px] tracking-[0.5em] font-brand uppercase">Alpha 0.08</span>
              </div>
            </header>

            <div className="grid md:grid-cols-2 gap-10 w-full max-w-4xl mx-auto">
              {/* Navigate to Client Portal */}
              <Link href="/client" className="group">
                <Card className="glass-container p-12 luxury-transition glow-pulse border-white/5 h-full flex flex-col items-center justify-center space-y-8 hover:-translate-y-4 opacity-0 animate-reveal-up stagger-1">
                  <div className="p-6 rounded-full bg-primary/10 text-primary luxury-transition group-hover:scale-110 group-hover:bg-primary/20">
                    <User size={48} strokeWidth={1} />
                  </div>
                  <div className="space-y-3">
                    <h2 className="text-4xl font-arabic font-medium text-primary">بوابة العميل</h2>
                    <p className="text-muted-foreground font-arabic font-light text-lg">تحليل WearDraw، محرك الميزانية، والملف الشخصي للأناقة.</p>
                  </div>
                  <div className="w-16 h-[1px] bg-primary/30 group-hover:w-full luxury-transition"></div>
                </Card>
              </Link>

              {/* Navigate to Merchant Dashboard */}
              <Link href="/merchant" className="group">
                <Card className="glass-container p-12 luxury-transition glow-pulse border-white/5 h-full flex flex-col items-center justify-center space-y-8 hover:-translate-y-4 opacity-0 animate-reveal-up stagger-2">
                  <div className="p-6 rounded-full bg-secondary/10 text-secondary luxury-transition group-hover:scale-110 group-hover:bg-secondary/20">
                    <Briefcase size={48} strokeWidth={1} />
                  </div>
                  <div className="space-y-3">
                    <h2 className="text-4xl font-arabic font-medium text-secondary">لوحة التاجر</h2>
                    <p className="text-muted-foreground font-arabic font-light text-lg">إستراتيجية الإنقاذ، إدارة المخزون بالدينار، والتحليلات.</p>
                  </div>
                  <div className="w-16 h-[1px] bg-secondary/30 group-hover:w-full luxury-transition"></div>
                </Card>
              </Link>
            </div>

            <footer className="pt-16 animate-reveal-up stagger-3 opacity-30">
              <p className="text-muted-foreground text-[10px] tracking-widest uppercase font-brand">
                &copy; 2024 WARDro SOVEREIGN SYSTEMS. ALL RIGHTS RESERVED.
              </p>
            </footer>
          </div>
        </main>
      )}
    </>
  );
}

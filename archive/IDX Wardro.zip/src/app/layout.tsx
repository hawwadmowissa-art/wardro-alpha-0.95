import type { Metadata } from 'next';
import './globals.css';
import Image from 'next/image';

export const metadata: Metadata = {
  title: 'Wardro | Sovereign Fashion Ecosystem',
  description: 'AI-powered fashion system for high-end collection management and sovereign styling.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet" />
      </head>
      <body className="font-arabic antialiased overflow-x-hidden min-h-screen">
        {/* Atmospheric Drifting Backgrounds */}
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#080706]">
          <div className="absolute inset-0 bg-gradient-to-b from-[#080706] via-[#0d0d0c] to-[#1A1A1A] opacity-100"></div>
          
          <div className="drifting-asset top-[10%] left-[5%] w-[400px] h-[600px] blur-[80px]">
            <Image src="https://picsum.photos/seed/fabric-glow/600/800" alt="Texture" fill className="object-cover opacity-20" />
          </div>
          <div className="drifting-asset bottom-[5%] right-[10%] w-[500px] h-[700px] blur-[100px]" style={{ animationDelay: '-30s' }}>
            <Image src="https://picsum.photos/seed/suit-glow/600/900" alt="Tailoring" fill className="object-cover opacity-15" />
          </div>
        </div>

        <div className="relative z-10">
          {children}
        </div>
      </body>
    </html>
  );
}

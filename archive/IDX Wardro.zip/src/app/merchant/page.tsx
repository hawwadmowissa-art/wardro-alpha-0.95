import { PortalNav } from '@/components/layout/portal-nav';
import { Card } from '@/components/ui/card';
import { 
  TrendingUp, 
  Package, 
  Calendar, 
  Video, 
  Users, 
  ArrowUpRight,
  Search
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const merchantLinks = [
  { name: 'Analytics', href: '/merchant' },
  { name: 'Inventory', href: '/merchant/inventory' },
  { name: 'Schedule', href: '/merchant/schedule' },
  { name: 'Media', href: '/merchant/media' },
];

export default function MerchantDashboard() {
  return (
    <div className="min-h-screen pt-24 pb-12 px-8">
      <PortalNav type="merchant" links={merchantLinks} />
      
      <main className="max-w-7xl mx-auto space-y-10">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 animate-reveal-up">
          <div className="space-y-1">
            <p className="text-secondary text-xs tracking-widest uppercase font-medium">Control Center</p>
            <h1 className="text-5xl font-headline">Operational <span className="text-secondary">Dashboard</span></h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4 luxury-transition group-hover:scale-110 group-hover:text-secondary" />
              <Input 
                placeholder="Rapid inventory search..." 
                className="pl-10 w-[300px] bg-white/5 border-white/10 focus:border-secondary luxury-transition text-xs"
              />
            </div>
            <Button className="bg-secondary text-white hover:bg-secondary/90 luxury-transition px-6 rounded-none text-xs uppercase tracking-widest">New Listing</Button>
          </div>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: 'Total Sales', value: '$1.2M', trend: '+12.4%', icon: TrendingUp },
            { label: 'In Stock', value: '1,420', trend: '-2.1%', icon: Package },
            { label: 'Upcoming Tasks', value: '18', trend: 'Priority', icon: Calendar },
            { label: 'Live Displays', value: '42', trend: 'Active', icon: Video },
          ].map((stat, i) => (
            <Card key={i} className={`glass-container p-6 space-y-4 luxury-transition animate-reveal-up stagger-${i+1}`}>
              <div className="flex justify-between items-start">
                <div className="p-2 rounded bg-secondary/10 text-secondary">
                  <stat.icon size={20} />
                </div>
                <span className={`text-[10px] font-mono ${stat.trend.startsWith('+') ? 'text-green-500' : 'text-secondary/60'}`}>{stat.trend}</span>
              </div>
              <div className="space-y-1">
                <p className="text-muted-foreground text-[10px] uppercase tracking-widest">{stat.label}</p>
                <p className="text-3xl font-headline">{stat.value}</p>
              </div>
            </Card>
          ))}
        </section>

        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 glass-container p-8 space-y-6 animate-reveal-up stagger-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <h2 className="text-xl font-headline tracking-wide uppercase">Inventory Metrics</h2>
              <div className="flex space-x-2">
                <Button variant="ghost" size="sm" className="text-[10px] uppercase text-muted-foreground hover:text-secondary">Weekly</Button>
                <Button variant="ghost" size="sm" className="text-[10px] uppercase text-secondary border-b border-secondary rounded-none">Monthly</Button>
              </div>
            </div>
            <div className="h-[300px] w-full flex items-end justify-between px-4 pb-4">
              {/* Simulated Chart Bars */}
              {[40, 60, 30, 90, 45, 70, 55, 80, 40, 65, 50, 85].map((h, i) => (
                <div key={i} className="w-[6%] bg-secondary/20 hover:bg-secondary luxury-transition relative group cursor-pointer" style={{ height: `${h}%` }}>
                  <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 luxury-transition text-[10px] font-mono whitespace-nowrap bg-black p-1 border border-secondary">
                    {h}% Vol.
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="glass-container p-8 space-y-6 animate-reveal-up stagger-5">
            <h2 className="text-xl font-headline tracking-wide uppercase border-b border-white/5 pb-4">Task Manifest</h2>
            <div className="space-y-4">
              {[
                { title: 'Paris Collection Shoot', time: 'Tomorrow, 09:00', priority: 'High' },
                { title: 'Stock Audit: Milan Warehouse', time: 'Wed, 14:00', priority: 'Med' },
                { title: 'Update Media: Fall/Winter', time: 'Friday, 11:30', priority: 'Low' },
                { title: 'Client Consultation: V.I.P.', time: 'Sat, 10:00', priority: 'High' },
              ].map((task, i) => (
                <div key={i} className="p-4 bg-white/5 border-l-2 border-secondary hover:bg-white/10 luxury-transition flex justify-between items-center group">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{task.title}</p>
                    <p className="text-[10px] text-muted-foreground font-mono">{task.time}</p>
                  </div>
                  <ArrowUpRight size={14} className="text-muted-foreground group-hover:text-secondary luxury-transition" />
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full border-white/10 text-muted-foreground hover:text-secondary hover:border-secondary luxury-transition text-xs uppercase tracking-tighter">View Full Schedule</Button>
          </Card>
        </div>
      </main>
    </div>
  );
}

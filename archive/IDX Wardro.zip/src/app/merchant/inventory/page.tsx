"use client";

import { PortalNav } from '@/components/layout/portal-nav';
import { Card } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search, Filter, Download, Plus, AlertTriangle, Crown, LifeBuoy, ShoppingBag } from 'lucide-react';
import Image from 'next/image';

const merchantLinks = [
  { name: 'التحليلات', href: '/merchant' },
  { name: 'المخزون', href: '/merchant/inventory' },
  { name: 'الجدول', href: '/merchant/schedule' },
  { name: 'الوسائط', href: '/merchant/media' },
];

const inventory = [
  { id: 'SKU-001', name: 'بليزر صوف إيطالي فاخر', category: 'ملابس', stock: 24, price: '85,000 DZD', status: 'متوفر', img: 'https://picsum.photos/seed/bespoke-suit-1/600/600' },
  { id: 'SKU-002', name: 'رداء سهرة مخملي ملكي', category: 'خارجية', stock: 5, price: '240,000 DZD', status: 'مخزون منخفض', img: 'https://picsum.photos/seed/velvet-suit/600/600' },
  { id: 'SKU-003', name: 'ساعة سيادية مرصعة', category: 'إكسسوارات', stock: 12, price: '1,200,000 DZD', status: 'متوفر', img: 'https://picsum.photos/seed/luxury-watch/600/600' },
  { id: 'SKU-004', name: 'حذاء لوفر جلدي يدوي', category: 'أحذية', stock: 0, price: '65,000 DZD', status: 'نفذ المخزون', img: 'https://picsum.photos/seed/leather-shoe/600/600' },
];

export default function InventoryPage() {
  return (
    <div className="min-h-screen pt-24 pb-12 px-8">
      <PortalNav type="merchant" links={merchantLinks} />
      
      <main className="max-w-7xl mx-auto space-y-10">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 animate-reveal-up">
          <div className="space-y-1">
            <p className="text-secondary text-xs tracking-widest uppercase font-medium">Assets Management</p>
            <h1 className="text-5xl font-headline">كتالوج <span className="text-secondary">المخزون</span></h1>
          </div>
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <div className="flex items-center px-4 py-2 bg-secondary/10 border border-secondary/20 text-secondary text-sm">
              <AlertTriangle className="mr-2 h-4 w-4" />
              <span className="font-arabic">٤ قطع تحتاج انتباهك</span>
            </div>
            <Button className="glass-container bg-secondary text-white hover:bg-secondary/90 rounded-none text-xs uppercase tracking-widest glow-pulse h-12 px-8">
              <Plus className="ml-2 h-4 w-4" /> <span className="font-arabic">إضافة قطعة جديدة</span>
            </Button>
          </div>
        </header>

        <section className="grid md:grid-cols-3 gap-6 animate-reveal-up stagger-1">
          <Card className="glass-container p-8 space-y-4 border-primary/20">
            <div className="flex items-center justify-between">
              <Crown className="text-primary h-8 w-8" />
              <Badge className="bg-primary/20 text-primary border-primary/30">نشط</Badge>
            </div>
            <h3 className="text-2xl font-headline font-arabic">القطعة السيادية</h3>
            <p className="text-muted-foreground text-sm font-light font-arabic">بليزر فيلفيت إيطالي - الأعلى مبيعاً هذا الأسبوع.</p>
          </Card>
          
          <Card className="glass-container p-8 space-y-4 border-secondary/20">
            <div className="flex items-center justify-between">
              <LifeBuoy className="text-secondary h-8 w-8" />
              <Badge variant="outline" className="border-secondary/30 text-secondary">عاجل</Badge>
            </div>
            <h3 className="text-2xl font-headline font-arabic">إستراتيجية الإنقاذ</h3>
            <p className="text-muted-foreground text-sm font-light font-arabic">تنسيق قطع الركود مع مجموعات الربيع القادمة.</p>
          </Card>

          <Card className="glass-container p-8 space-y-4">
            <div className="flex items-center justify-between">
              <ShoppingBag className="text-muted-foreground h-8 w-8" />
              <span className="text-xs text-muted-foreground uppercase tracking-widest">Recommendation</span>
            </div>
            <h3 className="text-2xl font-headline font-arabic">الشراء القادم</h3>
            <p className="text-muted-foreground text-sm font-light font-arabic">زيادة مخزون الأقمشة الكتانية بناءً على توقعات الصيف.</p>
          </Card>
        </section>

        <Card className="glass-container overflow-hidden animate-reveal-up stagger-2">
          <div className="p-6 border-b border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative w-full md:w-96">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input placeholder="بحث السريع في المخزون..." className="pr-10 bg-white/5 border-white/10 focus:border-secondary text-xs rounded-none text-right font-arabic" dir="rtl" />
            </div>
            <Button variant="ghost" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-secondary">
              <Filter className="ml-2 h-4 w-4" /> <span className="font-arabic">تصفية النتائج</span>
            </Button>
          </div>
          
          <Table>
            <TableHeader className="bg-white/5">
              <TableRow className="border-white/5 hover:bg-transparent">
                <TableHead className="text-right px-6 text-muted-foreground uppercase text-[10px] tracking-widest">القطعة</TableHead>
                <TableHead className="text-right text-muted-foreground uppercase text-[10px] tracking-widest">المعرف</TableHead>
                <TableHead className="text-right text-muted-foreground uppercase text-[10px] tracking-widest">الفئة</TableHead>
                <TableHead className="text-right text-muted-foreground uppercase text-[10px] tracking-widest">السعر</TableHead>
                <TableHead className="text-right text-muted-foreground uppercase text-[10px] tracking-widest">المخزون</TableHead>
                <TableHead className="text-right text-muted-foreground uppercase text-[10px] tracking-widest">الحالة</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {inventory.map((item, idx) => (
                <TableRow key={item.id} className="border-white/5 hover:bg-white/5 luxury-transition">
                  <TableCell className="px-6 py-4">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-12 h-12 glass-container relative rounded overflow-hidden">
                        <Image src={item.img} alt={item.name} fill className="object-cover" />
                      </div>
                      <span className="font-medium tracking-tight text-foreground font-arabic">{item.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-brand text-[10px] text-muted-foreground">{item.id}</TableCell>
                  <TableCell className="text-xs font-arabic">{item.category}</TableCell>
                  <TableCell className="text-xs font-bold text-primary font-brand">{item.price}</TableCell>
                  <TableCell className="text-xs font-brand">{item.stock}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`
                      text-[9px] uppercase tracking-tighter rounded-none border-0 px-2 py-0.5 font-arabic
                      ${item.status === 'متوفر' ? 'bg-green-500/10 text-green-500' : ''}
                      ${item.status === 'مخزون منخفض' ? 'bg-secondary/10 text-secondary' : ''}
                      ${item.status === 'نفذ المخزون' ? 'bg-red-500/10 text-red-500' : ''}
                    `}>
                      {item.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </main>
    </div>
  );
}

"use client";

import { PortalNav } from '@/components/layout/portal-nav';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { 
  Sparkles, 
  Shirt, 
  Search, 
  User, 
  Activity, 
  Target, 
  Wallet, 
  Crown, 
  LifeBuoy,
  Home,
  ChevronRight,
  ArrowLeft
} from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

const clientLinks = [
  { name: 'لوحة التحكم', href: '/client' },
  { name: 'WearDraw AI', href: '/client/weardraw' },
  { name: 'خزانتي', href: '/client/wardrobe' },
  { name: 'اكتشاف', href: '/client/discovery' },
];

export default function ClientPortal() {
  return (
    <div className="min-h-screen pt-24 pb-12 px-8">
      <PortalNav type="client" links={clientLinks} />
      
      <main className="max-w-7xl mx-auto space-y-16">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-8 animate-reveal-up">
          <div className="space-y-3">
            <h1 className="text-6xl md:text-8xl font-brand uppercase tracking-tighter">أهلاً بك، <span className="text-primary italic">إليجانس</span>.</h1>
            <p className="text-muted-foreground tracking-widest font-light max-w-2xl text-xl font-arabic">
              ملفك الشخصي للأناقة والقياسات السيادية.
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" className="glass-container h-12 flex items-center gap-3 px-6 rounded-none border-white/10 hover:border-primary/40 group">
                <span className="text-[10px] uppercase tracking-widest font-arabic">العودة للرئيسية</span>
                <Home className="text-primary w-4 h-4 luxury-transition group-hover:scale-110" />
              </Button>
            </Link>
          </div>
        </header>

        <section className="grid lg:grid-cols-12 gap-8">
          {/* Profile & Measurements */}
          <Card className="lg:col-span-4 glass-container p-10 space-y-8 animate-reveal-up stagger-1">
            <div className="flex items-center space-x-4 rtl:space-x-reverse border-b border-white/5 pb-6">
              <User className="text-primary w-10 h-10" />
              <h2 className="text-3xl font-brand font-arabic">القياسات الشخصية</h2>
            </div>
            
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase tracking-widest text-primary/60 font-arabic">الطول (سم)</Label>
                  <Input type="number" placeholder="180" className="bg-white/5 border-white/10 rounded-none h-12 focus:border-primary text-center font-brand" />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase tracking-widest text-primary/60 font-arabic">العمر</Label>
                  <Input type="number" placeholder="28" className="bg-white/5 border-white/10 rounded-none h-12 focus:border-primary text-center font-brand" />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <Label className="text-[10px] uppercase tracking-widest text-primary/60 font-arabic">البنية العضلية / التعريف</Label>
                  <Activity size={16} className="text-primary/40" />
                </div>
                <Slider defaultValue={[50]} max={100} step={1} className="py-4" />
                <div className="flex justify-between text-[10px] text-muted-foreground font-arabic uppercase tracking-tighter">
                  <span>نحيف</span>
                  <span>رياضي</span>
                  <span>ضخم</span>
                </div>
              </div>

              <Button className="w-full h-14 bg-primary text-black rounded-none uppercase tracking-[0.2em] text-xs glow-pulse font-arabic">
                تحديث بيانات الجسم
              </Button>
            </div>
          </Card>

          {/* Budget Engine & Occasions */}
          <div className="lg:col-span-8 space-y-8">
            <Card className="glass-container p-10 space-y-8 animate-reveal-up stagger-2">
              <div className="flex items-center justify-between border-b border-white/5 pb-6">
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  <Wallet className="text-primary w-10 h-10" />
                  <h2 className="text-3xl font-brand font-arabic">محرك الميزانية</h2>
                </div>
                <div className="text-primary font-brand text-2xl tracking-widest">DZD</div>
              </div>

              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <p className="text-muted-foreground font-light italic text-lg font-arabic">
                    "حدد ميزانيتك لنقترح لك التنسيق الأمثل من خزانك والقطع المتاحة."
                  </p>
                  <div className="relative">
                    <Input 
                      placeholder="أدخل الميزانية المتاحة (دج)..." 
                      className="h-16 text-2xl bg-white/5 border-white/10 rounded-none pr-12 text-right font-brand" 
                    />
                    <Target className="absolute left-4 top-1/2 -translate-y-1/2 text-primary/40 h-6 w-6" />
                  </div>
                  <Button className="w-full h-16 shimmer-button text-white rounded-none uppercase tracking-[0.3em] text-[10px] font-bold shadow-[0_0_30px_rgba(210,175,105,0.3)] hover:scale-[1.02] luxury-transition font-arabic flex items-center justify-center gap-4">
                    <span>اكتشف تنسيقاتي</span>
                    <ChevronRight size={18} />
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: 'يومي', icon: Activity },
                    { label: 'مناسبات خاصة', icon: Crown },
                    { label: 'توفير المتاح', icon: LifeBuoy },
                    { label: 'اكتشاف قطع', icon: Search },
                  ].map((item, i) => (
                    <Button key={i} variant="outline" className="h-24 flex flex-col items-center justify-center space-y-3 border-white/5 hover:border-primary/40 hover:bg-primary/5 rounded-none luxury-transition">
                      <item.icon size={24} className="text-primary/60" />
                      <span className="text-[10px] uppercase tracking-widest font-arabic">{item.label}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </Card>

            <div className="grid md:grid-cols-2 gap-8 animate-reveal-up stagger-3">
              <Link href="/client/weardraw">
                <Card className="glass-container h-48 flex items-center justify-center space-x-6 rtl:space-x-reverse group hover:bg-white/5">
                  <Sparkles className="text-primary w-12 h-12 group-hover:scale-110 luxury-transition" />
                  <div className="text-right">
                    <h3 className="text-3xl font-brand font-arabic">WearDraw AI</h3>
                    <p className="text-muted-foreground text-xs uppercase tracking-widest font-arabic">تحليل الطلة فائق الدقة</p>
                  </div>
                </Card>
              </Link>
              <Link href="/client/wardrobe">
                <Card className="glass-container h-48 flex items-center justify-center space-x-6 rtl:space-x-reverse group hover:bg-white/5">
                  <Shirt className="text-primary w-12 h-12 group-hover:scale-110 luxury-transition" />
                  <div className="text-right">
                    <h3 className="text-3xl font-brand font-arabic">خزانتي الرقمية</h3>
                    <p className="text-muted-foreground text-xs uppercase tracking-widest font-arabic">إدارة المجموعة السيادية</p>
                  </div>
                </Card>
              </Link>
            </div>
          </div>
        </section>

        {/* 8K Photorealistic Coordinations */}
        <section className="space-y-12 animate-reveal-up stagger-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-6">
            <h2 className="text-4xl font-brand font-arabic">تنسيقات 8K المختارة</h2>
            <span className="text-primary text-[10px] uppercase tracking-[0.4em] font-brand">ULTRA HD 8K RENDER</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="group cursor-pointer">
                <div className="aspect-[16/9] glass-container relative overflow-hidden">
                  <Image 
                    src={`https://picsum.photos/seed/luxury-suit-coord-${i}/1200/675`} 
                    alt={`Coordination ${i}`} 
                    fill 
                    className="object-cover luxury-transition group-hover:scale-105"
                    data-ai-hint="bespoke suit"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 luxury-transition flex flex-col items-center justify-center space-y-4">
                    <h4 className="text-2xl font-brand text-primary font-arabic">مجموعة السيادة {i}</h4>
                    <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-black rounded-none uppercase text-[10px] tracking-widest font-arabic">استكشاف المكونات</Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

"use client";

import { useState } from 'react';
import { PortalNav } from '@/components/layout/portal-nav';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Sparkles, Upload, Loader2, CheckCircle2 } from 'lucide-react';
import { aiOutfitAssessment, AiOutfitAssessmentOutput } from '@/ai/flows/ai-outfit-assessment-flow';
import Image from 'next/image';

const clientLinks = [
  { name: 'Dashboard', href: '/client' },
  { name: 'WearDraw AI', href: '/client/weardraw' },
  { name: 'My Wardrobe', href: '/client/wardrobe' },
  { name: 'Discovery', href: '/client/discovery' },
];

export default function WearDrawPage() {
  const [description, setDescription] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<AiOutfitAssessmentOutput | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAssessment = async () => {
    if (!image || !description) return;
    setIsProcessing(true);
    try {
      const res = await aiOutfitAssessment({ photoDataUri: image, description });
      // Simulate "cinematic micro-transition" delay
      setTimeout(() => {
        setResult(res);
        setIsProcessing(false);
      }, 2000);
    } catch (error) {
      console.error(error);
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-8">
      <PortalNav type="client" links={clientLinks} />
      
      <main className="max-w-4xl mx-auto space-y-12">
        <header className="text-center space-y-4 animate-reveal-up">
          <h1 className="text-6xl font-headline text-primary">WearDraw</h1>
          <p className="text-muted-foreground font-light tracking-widest uppercase text-xs">
            The Digital Stylist's Master Atelier
          </p>
        </header>

        {!result ? (
          <Card className="glass-container p-12 space-y-10 animate-reveal-up stagger-1">
            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <label className="block space-y-3">
                  <span className="text-xs uppercase tracking-widest text-primary font-medium">Capture Your Ensemble</span>
                  <div className={`aspect-[3/4] border-2 border-dashed ${image ? 'border-primary/50' : 'border-white/10'} rounded-lg flex flex-col items-center justify-center overflow-hidden luxury-transition hover:border-primary/40 group relative cursor-pointer`}>
                    {image ? (
                      <>
                        <Image src={image} alt="Uploaded" fill className="object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center luxury-transition">
                          <span className="text-xs uppercase tracking-widest text-white">Change Image</span>
                        </div>
                      </>
                    ) : (
                      <div className="text-center space-y-4">
                        <Upload className="w-12 h-12 text-muted-foreground mx-auto" strokeWidth={1} />
                        <p className="text-muted-foreground text-sm">Drop your photo here or browse</p>
                      </div>
                    )}
                    <input type="file" className="hidden" onChange={handleImageUpload} accept="image/*" />
                  </div>
                </label>
              </div>

              <div className="space-y-8 flex flex-col justify-center">
                <div className="space-y-4">
                  <span className="text-xs uppercase tracking-widest text-primary font-medium">Styling Context</span>
                  <Textarea 
                    placeholder="Describe the occasion, your style intent, or specific concerns..."
                    className="bg-white/5 border-white/10 focus:border-primary min-h-[150px] font-light luxury-transition gold-border-focus"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>

                <Button 
                  disabled={!image || !description || isProcessing}
                  onClick={handleAssessment}
                  className="w-full h-16 bg-primary text-black hover:bg-primary/90 text-sm uppercase tracking-[0.3em] font-medium luxury-transition glow-pulse rounded-none"
                >
                  {isProcessing ? (
                    <Loader2 className="animate-spin mr-2" />
                  ) : (
                    <Sparkles className="mr-2" size={18} />
                  )}
                  {isProcessing ? 'Analyzing Silhouette...' : 'Initiate Assessment'}
                </Button>
              </div>
            </div>
          </Card>
        ) : (
          <div className="space-y-10 animate-reveal-up">
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="glass-container p-8 space-y-4 text-center">
                <span className="text-xs uppercase tracking-widest text-primary opacity-60">Stylistic Rating</span>
                <div className="text-8xl font-headline text-primary">{result.rating}<span className="text-2xl opacity-40">/10</span></div>
              </Card>
              
              <Card className="glass-container md:col-span-2 p-8 space-y-6">
                <div className="flex items-center space-x-2 text-primary">
                  <CheckCircle2 size={18} />
                  <span className="text-xs uppercase tracking-[0.3em]">Master Critique</span>
                </div>
                <p className="text-lg font-light leading-relaxed text-foreground/90 italic">
                  &quot;{result.assessment}&quot;
                </p>
              </Card>
            </div>

            <Card className="glass-container p-10 space-y-8">
              <h3 className="text-2xl font-headline border-b border-white/10 pb-4">Personalized Enhancements</h3>
              <div className="grid md:grid-cols-2 gap-8">
                {result.suggestions.map((s, idx) => (
                  <div key={idx} className="flex space-x-4 group">
                    <span className="text-primary font-mono text-sm opacity-50">0{idx + 1}</span>
                    <p className="text-muted-foreground font-light leading-relaxed group-hover:text-foreground luxury-transition">{s}</p>
                  </div>
                ))}
              </div>
            </Card>

            <div className="flex justify-center">
              <Button 
                variant="outline" 
                onClick={() => setResult(null)}
                className="border-primary/30 text-primary hover:bg-primary hover:text-black luxury-transition text-xs uppercase tracking-widest rounded-none h-12 px-10"
              >
                New Assessment
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

import Link from 'next/link';
import { Diamond } from 'lucide-react';

interface PortalNavProps {
  type: 'client' | 'merchant';
  links: { name: string; href: string }[];
}

export function PortalNav({ type, links }: PortalNavProps) {
  const accentColor = type === 'client' ? 'text-primary' : 'text-secondary';
  
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-10 py-8 glass-container border-b border-white/5 rounded-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center space-x-4 rtl:space-x-reverse group">
          <Diamond className={`w-8 h-8 ${accentColor} luxury-transition group-hover:rotate-45`} strokeWidth={1.5} />
          <span className="text-3xl font-headline tracking-[0.2em] uppercase">Wardro</span>
        </Link>
        
        <div className="hidden md:flex items-center space-x-12 rtl:space-x-reverse">
          {links.map((link) => (
            <Link 
              key={link.href} 
              href={link.href} 
              className="text-xs tracking-widest uppercase text-muted-foreground hover:text-foreground luxury-transition gold-border-focus py-2"
            >
              {link.name}
            </Link>
          ))}
        </div>

        <div className="flex items-center space-x-6 rtl:space-x-reverse">
          <div className={`text-[10px] font-mono tracking-widest opacity-40 px-3 py-1.5 border border-white/10 rounded-none uppercase`}>
            {type === 'client' ? 'بوابة العميل' : 'لوحة التاجر'}
          </div>
        </div>
      </div>
    </nav>
  );
}
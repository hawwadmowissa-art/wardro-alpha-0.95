"use client";

import { useEffect, useState } from "react";

export function SplashScreen({ onComplete }: { onComplete: () => void }) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 800);
    }, 4500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-[#080706] flex flex-col items-center justify-center overflow-hidden transition-opacity duration-1000 ease-in-out">
      <div className="relative flex flex-col items-center gap-8 logo-fluid-burst">
        <svg className="main-logo drop-shadow-[0_0_20px_rgba(200,168,100,0.3)]" viewBox="0 0 140 140" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <filter id="glow-f"><feGaussianBlur stdDeviation="2" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
          </defs>
          <path d="M70 18 L30 38 L22 55 L35 55 L35 115 L105 115 L105 55 L118 55 L110 38 Z"
            fill="none" stroke="#C8A864" strokeWidth="2.5" strokeLinejoin="round"
            strokeDasharray="400" strokeDashoffset="400" filter="url(#glow-f)">
            <animate attributeName="stroke-dashoffset" from="400" to="0" dur="1.8s" begin="0.3s" fill="freeze" calcMode="spline" keySplines="0.16 1 0.3 1"/>
            <animate attributeName="opacity" from="0" to="1" dur="0.3s" begin="0.3s" fill="freeze"/>
          </path>
          <path d="M70 18 L52 48 L70 42 L88 48 Z"
            fill="rgba(200,168,100,.0)" stroke="#C8A864" strokeWidth="2" strokeLinejoin="round"
            strokeDasharray="120" strokeDashoffset="120">
            <animate attributeName="stroke-dashoffset" from="120" to="0" dur="1s" begin="1.2s" fill="freeze" calcMode="spline" keySplines="0.16 1 0.3 1"/>
            <animate attributeName="fill" from="rgba(200,168,100,0)" to="rgba(200,168,100,.15)" dur="0.6s" begin="2s" fill="freeze"/>
          </path>
          <text x="38" y="92" className="font-brand" fontSize="28" fontWeight="300" fill="#C8A864" opacity="0">
            W
            <animate attributeName="opacity" from="0" to="1" dur="0.6s" begin="1.6s" fill="freeze"/>
          </text>
          <text x="82" y="92" className="font-brand" fontSize="28" fontWeight="300" fill="#C8A864" opacity="0">
            R
            <animate attributeName="opacity" from="0" to="1" dur="0.6s" begin="1.8s" fill="freeze"/>
          </text>
        </svg>

        <div className="text-center">
          <h1 className="text-7xl font-brand tracking-[0.4em] text-primary uppercase">
            WARD<span className="lowercase">ro</span>
          </h1>
          <p className="text-primary/40 text-[10px] tracking-[0.8em] uppercase font-light mt-4 font-arabic">المنظومة السيادية للأزياء</p>
        </div>
      </div>
    </div>
  );
}
"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Sparkles, User, Briefcase } from 'lucide-react';
import Image from 'next/image';

interface OnboardingProps {
  onComplete: () => void;
}

const steps = [
  {
    title: "نظام WEARDRAW AI السيادي",
    description: "اكتشف محرك الذكاء الاصطناعي الأكثر تقدماً لتحليل أناقتك الشخصية. نظام متكامل يفهم أبعادك ويقدم لك تقييمات احترافية لطلتك اليومية.",
    icon: Sparkles,
    image: "https://picsum.photos/seed/sovereign-ai/1200/800",
    stats: "98%",
    statLabel: "دقة التنسيق"
  },
  {
    title: "محرك الأناقة للعملاء",
    description: "إدارة ميزانيتك بالدينار الجزائري، تحديد مناسباتك، وبناء ملفك الجسدي بدقة متناهية للحصول على تنسيقات 8K واقعية تماماً.",
    icon: User,
    image: "https://picsum.photos/seed/client-style/1200/800",
    stats: "DZD",
    statLabel: "تحكم مالي"
  },
  {
    title: "إستراتيجية التاجر المتطورة",
    description: "إدارة المخزون، إستراتيجيات الإنقاذ للقطع الراكدة، وتحليلات البيع المتقدمة. تحكم كامل في مجموعتك التجارية بالعملة الوطنية.",
    icon: Briefcase,
    image: "https://picsum.photos/seed/merchant-inventory/1200/800",
    stats: "AI",
    statLabel: "ذكاء العمليات"
  }
];

export function Onboarding({ onComplete }: OnboardingProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  const Icon = steps[currentStep].icon;

  return (
    <div className="fixed inset-0 z-50 bg-[#080706] flex items-center justify-center p-6">
      <Card className="glass-container w-full max-w-6xl h-[750px] grid md:grid-cols-2 overflow-hidden animate-reveal-up">
        <div className="relative h-full hidden md:block">
          <Image 
            src={steps[currentStep].image} 
            alt="Onboarding" 
            fill 
            className="object-cover opacity-30 luxury-transition"
            data-ai-hint="luxury suit tailored"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#080706] via-transparent to-transparent"></div>
          
          <div className="absolute bottom-16 right-16 flex flex-col items-end">
            <span className="text-8xl font-brand text-primary opacity-50">{steps[currentStep].stats}</span>
            <span className="text-xs uppercase tracking-widest text-primary/40 font-arabic">{steps[currentStep].statLabel}</span>
          </div>
        </div>
        
        <div className="p-16 flex flex-col justify-center space-y-12 bg-black/40">
          <div className="space-y-8">
            <div className="p-5 bg-primary/10 w-fit text-primary border border-primary/20">
              <Icon size={52} strokeWidth={1} />
            </div>
            <h2 className="text-5xl font-brand text-primary leading-tight font-arabic">{steps[currentStep].title}</h2>
            <p className="text-xl text-muted-foreground font-light leading-relaxed font-arabic">
              {steps[currentStep].description}
            </p>
          </div>

          <div className="flex items-center justify-between pt-12">
            <div className="flex space-x-3 rtl:space-x-reverse">
              {steps.map((_, i) => (
                <div 
                  key={i} 
                  className={`h-1 luxury-transition ${i === currentStep ? 'w-16 bg-primary' : 'w-5 bg-white/10'}`}
                />
              ))}
            </div>
            
            <div className="flex items-center gap-6">
              <button onClick={onComplete} className="text-xs uppercase tracking-widest text-muted-foreground hover:text-primary luxury-transition font-arabic">تخطي</button>
              <Button 
                onClick={nextStep}
                className="bg-primary text-black hover:bg-primary/90 px-14 h-16 rounded-none text-xl uppercase tracking-widest glow-pulse flex items-center space-x-4 rtl:space-x-reverse font-arabic"
              >
                <span>{currentStep === steps.length - 1 ? 'ابدأ السيادة' : 'التالي'}</span>
                <ArrowLeft size={20} className="mr-2" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}